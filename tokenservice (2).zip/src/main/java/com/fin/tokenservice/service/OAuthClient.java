package com.fin.tokenservice.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fin.tokenservice.entity.AccessToken;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;
import java.util.UUID;

@Component
public class OAuthClient {
    private final WebClient webClient;
    private final ObjectMapper objectMapper;

    @Value("${oauth.client.id}")
    private String clientId;

    @Value("${oauth.client.secret}")
    private String clientSecret;

    public OAuthClient(WebClient.Builder webClientBuilder, ObjectMapper objectMapper) {
        this.webClient = webClientBuilder.build();
        this.objectMapper = objectMapper;
    }

    public AccessToken fetchToken() {
        // Replace with your IdP call
        String token = "access-token-" + UUID.randomUUID();
        long expiresIn = 3600 * 1000L;
        AccessToken t = new AccessToken();
        t.setToken(token);
        t.setExpiresAt(System.currentTimeMillis() + expiresIn - 5000);
        return t;
        /*String tokenUrl = "https://github.com/login/oauth/access_token";

        try {
            String response = webClient.post()
                    .uri(tokenUrl)
                    .header("Accept", "application/json")
                    .contentType(MediaType.APPLICATION_JSON)
                    .bodyValue(Map.of(
                            "client_id", clientId,
                            "client_secret", clientSecret,
                            "redirect_uri", "http://localhost:8000"
                    ))
                    .retrieve()
                    .bodyToMono(String.class)
                    .block();

            JsonNode node = objectMapper.readTree(response);

            if (node.has("error")) {
                throw new RuntimeException("OAuth error: " + node.get("error_description").asText());
            }

            if (!node.hasNonNull("access_token")) {
                throw new RuntimeException("No access token in response. Response: " + response);
            }

            String token = node.get("access_token").asText();
            long expiresIn = 3600 * 1000; // Default to 1 hour

            AccessToken accessToken = new AccessToken();
            accessToken.setToken(token);
            accessToken.setExpiresAt(System.currentTimeMillis() + expiresIn - 5000);

            return accessToken;
        } catch (Exception e) {
            throw new RuntimeException("Failed to fetch OAuth token: " + e.getMessage(), e);
        }*/
    }
}