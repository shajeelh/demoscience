package com.fin.tokenservice.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fin.tokenservice.entity.AccessToken;
import com.fin.tokenservice.repository.AccessTokenRepository;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.map.IMap;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

@Service
public class TokenService {

    private final HazelcastInstance hazelcast;
    private final AccessTokenRepository tokenRepo;
    private final WebClient webClient;
    private final OAuthClient oAuthClient;

    private static final String TOKEN_MAP = "access-token-map";
    private static final String LOCK_KEY = "token-refresh-lock";

    public TokenService(HazelcastInstance hazelcast, AccessTokenRepository tokenRepo, OAuthClient oAuthClient) {
        this.hazelcast = hazelcast;
        this.tokenRepo = tokenRepo;
        this.oAuthClient = oAuthClient;
        this.webClient = WebClient.create();
    }

    public String getAccessToken() {
        IMap<String, AccessToken> map = hazelcast.getMap(TOKEN_MAP);
        AccessToken cached = map.get("token");

        if (cached != null && !cached.isExpired()) return cached.getToken();

        return refreshTokenWithMapLock();
    }

    public String refreshTokenWithMapLock() {
        IMap<String, String> lockMap = hazelcast.getMap("token-lock-map");
        IMap<String, AccessToken> tokenMap = hazelcast.getMap("access-token-map");

        try {
            boolean locked = lockMap.tryLock("refresh-token-lock", 10, TimeUnit.SECONDS);
            if (!locked) {
                Thread.sleep(1000);
                return getAccessToken(); // retry
            }

            try {
                AccessToken current = tokenMap.get("token");
                if (current != null && !current.isExpired()) {
                    return current.getToken();
                }

                AccessToken dbToken = tokenRepo.findById(1L).orElse(null);
                if (dbToken != null && !dbToken.isExpired()) {
                    tokenMap.put("token", dbToken);
                    return dbToken.getToken();
                }

                AccessToken newToken = fetchNewToken();
                tokenMap.put("token", newToken, newToken.getExpiresAt() - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
                tokenRepo.save(newToken);
                return newToken.getToken();

            } finally {
                lockMap.unlock("refresh-token-lock");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Lock interrupted", e);
        }
    }

    public void invalidateToken() {
        hazelcast.getMap(TOKEN_MAP).delete("token");
        tokenRepo.deleteById(1L);
    }

    private AccessToken fetchNewToken() {
        return oAuthClient.fetchToken();
    }
}
