package com.fin.tokenservice.dto;

public class TokenResponseDto {
}
