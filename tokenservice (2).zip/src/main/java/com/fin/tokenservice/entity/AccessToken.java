package com.fin.tokenservice.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class AccessToken {

    @Id
    private Long id = 1L;

    private String token;
    private long expiresAt;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public long getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(long expiresAt) {
        this.expiresAt = expiresAt;
    }

    public boolean isExpired() {
        return System.currentTimeMillis() >= expiresAt;
    }
}

